
# Real-time Traffic Prediction

## Description
This project implements a real-time traffic prediction system using historical traffic data. The system utilizes time series analysis and machine learning (LSTM) to predict traffic conditions. An interactive map is generated to display the predicted traffic conditions.

## Tools and Technologies
- Python
- TensorFlow
- pandas
- folium (for interactive map visualization)

## Project Structure
```
real_time_traffic_prediction/
│
├── data/
│   ├── historical_traffic_data.csv
│   └── traffic_zones.geojson
│
├── notebooks/
│   ├── data_preprocessing.ipynb
│   └── model_training.ipynb
│
├── src/
│   ├── __init__.py
│   ├── data_loader.py
│   ├── preprocess.py
│   ├── model.py
│   └── predict.py
│
├── models/
│   └── traffic_model.h5
│
├── app.py
├── requirements.txt
└── README.md
```

## Data
- `historical_traffic_data.csv`: Contains historical traffic data with timestamps, zone IDs, and traffic volumes.
- `traffic_zones.geojson`: Contains GeoJSON data for the traffic zones.

## Notebooks
- `data_preprocessing.ipynb`: Jupyter notebook for data preprocessing.
- `model_training.ipynb`: Jupyter notebook for model training using TensorFlow.

## Source Code
- `data_loader.py`: Module for loading data.
- `preprocess.py`: Module for preprocessing data.
- `model.py`: Module for defining the LSTM model.
- `predict.py`: Module for making predictions.

## Usage

### 1. Install Dependencies
Ensure you have Python installed. Then, install the required packages using the following command:
```
pip install -r requirements.txt
```

### 2. Data Preprocessing
Run the data preprocessing notebook to preprocess the historical traffic data. This will generate a preprocessed data file.
```
jupyter notebook notebooks/data_preprocessing.ipynb
```

### 3. Model Training
Run the model training notebook to train the traffic prediction model. This will save the trained model.
```
jupyter notebook notebooks/model_training.ipynb
```

### 4. Generate Traffic Prediction Map
Run the `app.py` script to generate the interactive traffic prediction map. The map will be saved as `traffic_prediction_map.html`.
```
python app.py
```

## Output
The output of the project is an interactive HTML map (`traffic_prediction_map.html`) showing the predicted traffic conditions in different zones. The markers on the map indicate the traffic volume, with different colors representing different levels of traffic.

## License
This project is licensed under the MIT License.

## Acknowledgments
- TensorFlow for providing the machine learning framework.
- pandas for data manipulation and analysis.
- folium for interactive map visualization.
