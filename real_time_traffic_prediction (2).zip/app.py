
import pandas as pd
import folium
from src.data_loader import load_data
from src.preprocess import preprocess_data
from src.model import create_model
from src.predict import make_predictions

# Load and preprocess data
data = load_data('data/historical_traffic_data.csv')
preprocessed_data = preprocess_data(data)

# Load model and make predictions
model = create_model((1, 2))
model.load_weights('models/traffic_model.h5')
predictions = make_predictions(model, preprocessed_data)

# Create interactive map
m = folium.Map(location=[45.5236, -122.6750])

# Add traffic prediction markers to map
for idx, row in preprocessed_data.iterrows():
    folium.Marker(
        location=[45.5236 + idx * 0.01, -122.6750 + idx * 0.01],  # Adjust with fake lat/lon
        popup=f"Traffic Volume: {predictions[idx][0]}",
        icon=folium.Icon(color='red' if predictions[idx][0] > 30 else 'green')
    ).add_to(m)

# Save map to HTML
m.save('traffic_prediction_map.html')

print("Traffic prediction map created and saved.")
